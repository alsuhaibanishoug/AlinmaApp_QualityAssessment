package androidx.localbroadcastmanager;

public final class R {
    private R() {
    }
}
