package androidx.work;

public enum ExistingPeriodicWorkPolicy {
    REPLACE,
    KEEP
}
