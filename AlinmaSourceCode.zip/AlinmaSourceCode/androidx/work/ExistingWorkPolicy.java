package androidx.work;

public enum ExistingWorkPolicy {
    REPLACE,
    KEEP,
    APPEND
}
