package androidx.work;

public enum BackoffPolicy {
    EXPONENTIAL,
    LINEAR
}
