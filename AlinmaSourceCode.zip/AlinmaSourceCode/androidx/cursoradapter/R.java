package androidx.cursoradapter;

public final class R {
    private R() {
    }
}
