package androidx.transition;

import android.view.View;
import androidx.annotation.NonNull;

/* access modifiers changed from: package-private */
public interface ViewGroupOverlayImpl extends ViewOverlayImpl {
    void add(@NonNull View view);

    void remove(@NonNull View view);
}
