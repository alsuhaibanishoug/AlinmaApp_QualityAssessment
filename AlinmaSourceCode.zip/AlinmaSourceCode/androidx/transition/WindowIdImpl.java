package androidx.transition;

/* access modifiers changed from: package-private */
public interface WindowIdImpl {
}
