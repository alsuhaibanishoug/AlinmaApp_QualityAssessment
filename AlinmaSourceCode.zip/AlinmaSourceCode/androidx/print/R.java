package androidx.print;

public final class R {
    private R() {
    }
}
