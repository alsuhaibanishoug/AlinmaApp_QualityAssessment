package androidx.documentfile;

public final class R {
    private R() {
    }
}
