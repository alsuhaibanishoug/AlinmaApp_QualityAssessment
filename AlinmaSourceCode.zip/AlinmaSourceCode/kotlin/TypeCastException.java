package kotlin;

public class TypeCastException extends ClassCastException {
    public TypeCastException() {
    }

    public TypeCastException(String str) {
        super(str);
    }
}
