package kotlin.ranges;

import kotlin.Metadata;

@Metadata(bv = {1, 0, 2}, d1 = {"kotlin/ranges/RangesKt__RangesKt", "kotlin/ranges/RangesKt___RangesKt"}, k = 4, mv = {1, 1, 8}, xi = 1)
public final class RangesKt extends RangesKt___RangesKt {
    private RangesKt() {
    }
}
