package kotlin.io;

import kotlin.Metadata;

@Metadata(bv = {1, 0, 2}, d1 = {"kotlin/io/FilesKt__FilePathComponentsKt", "kotlin/io/FilesKt__FileReadWriteKt", "kotlin/io/FilesKt__FileTreeWalkKt", "kotlin/io/FilesKt__UtilsKt"}, k = 4, mv = {1, 1, 8}, xi = 1)
public final class FilesKt extends FilesKt__UtilsKt {
    private FilesKt() {
    }
}
