package kotlin;

@Metadata(bv = {1, 0, 2}, d1 = {"\u0000X\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000*\u001a\b\u0007\u0010\u0000\"\u00020\u00012\u00020\u0001B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*\u001a\b\u0007\u0010\u0005\"\u00020\u00062\u00020\u0006B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*,\b\u0007\u0010\u0007\u001a\u0004\b\u0000\u0010\b\"\b\u0012\u0004\u0012\u0002H\b0\t2\b\u0012\u0004\u0012\u0002H\b0\tB\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*\u001a\b\u0007\u0010\n\"\u00020\u000b2\u00020\u000bB\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*\u001a\b\u0007\u0010\f\"\u00020\r2\u00020\rB\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*\u001a\b\u0007\u0010\u000e\"\u00020\u000f2\u00020\u000fB\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*\u001a\b\u0007\u0010\u0010\"\u00020\u00112\u00020\u0011B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*\u001a\b\u0007\u0010\u0012\"\u00020\u00132\u00020\u0013B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*\u001a\b\u0007\u0010\u0014\"\u00020\u00152\u00020\u0015B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*\u001a\b\u0007\u0010\u0016\"\u00020\u00172\u00020\u0017B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*\u001a\b\u0007\u0010\u0018\"\u00020\u00192\u00020\u0019B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*\u001a\b\u0007\u0010\u001a\"\u00020\u001b2\u00020\u001bB\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*\u001a\b\u0007\u0010\u001c\"\u00020\u001d2\u00020\u001dB\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004¨\u0006\u001e"}, d2 = {"AssertionError", "Ljava/lang/AssertionError;", "Lkotlin/SinceKotlin;", "version", "1.1", "ClassCastException", "Ljava/lang/ClassCastException;", "Comparator", "T", "Ljava/util/Comparator;", "Error", "Ljava/lang/Error;", "Exception", "Ljava/lang/Exception;", "IllegalArgumentException", "Ljava/lang/IllegalArgumentException;", "IllegalStateException", "Ljava/lang/IllegalStateException;", "IndexOutOfBoundsException", "Ljava/lang/IndexOutOfBoundsException;", "NoSuchElementException", "Ljava/util/NoSuchElementException;", "NullPointerException", "Ljava/lang/NullPointerException;", "NumberFormatException", "Ljava/lang/NumberFormatException;", "RuntimeException", "Ljava/lang/RuntimeException;", "UnsupportedOperationException", "Ljava/lang/UnsupportedOperationException;", "kotlin-runtime"}, k = 2, mv = {1, 1, 8})
/* compiled from: TypeAliases.kt */
public final class TypeAliasesKt {
    @SinceKotlin(version = "1.1")
    public static /* synthetic */ void AssertionError$annotations() {
    }

    @SinceKotlin(version = "1.1")
    public static /* synthetic */ void ClassCastException$annotations() {
    }

    @SinceKotlin(version = "1.1")
    public static /* synthetic */ void Comparator$annotations() {
    }

    @SinceKotlin(version = "1.1")
    public static /* synthetic */ void Error$annotations() {
    }

    @SinceKotlin(version = "1.1")
    public static /* synthetic */ void Exception$annotations() {
    }

    @SinceKotlin(version = "1.1")
    public static /* synthetic */ void IllegalArgumentException$annotations() {
    }

    @SinceKotlin(version = "1.1")
    public static /* synthetic */ void IllegalStateException$annotations() {
    }

    @SinceKotlin(version = "1.1")
    public static /* synthetic */ void IndexOutOfBoundsException$annotations() {
    }

    @SinceKotlin(version = "1.1")
    public static /* synthetic */ void NoSuchElementException$annotations() {
    }

    @SinceKotlin(version = "1.1")
    public static /* synthetic */ void NullPointerException$annotations() {
    }

    @SinceKotlin(version = "1.1")
    public static /* synthetic */ void NumberFormatException$annotations() {
    }

    @SinceKotlin(version = "1.1")
    public static /* synthetic */ void RuntimeException$annotations() {
    }

    @SinceKotlin(version = "1.1")
    public static /* synthetic */ void UnsupportedOperationException$annotations() {
    }
}
