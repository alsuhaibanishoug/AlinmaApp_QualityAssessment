package kotlin.sequences;

import kotlin.Metadata;

@Metadata(bv = {1, 0, 2}, d1 = {"kotlin/sequences/SequencesKt__SequencesKt", "kotlin/sequences/SequencesKt___SequencesKt"}, k = 4, mv = {1, 1, 8}, xi = 1)
public final class SequencesKt extends SequencesKt___SequencesKt {
    private SequencesKt() {
    }
}
